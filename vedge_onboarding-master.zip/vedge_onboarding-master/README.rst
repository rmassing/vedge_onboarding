VEdge Bulk On-boarding
==============================================

---------------

What is it?
-----------
This program is designed to allow easy on-boarding of multiple users for vEdge.



Installation
------------


Execution
---------



Contributions
-------------

1. Open an issue for your suggested contribution.

2. Create a branch based on dev where you will work on your issue.

3. Commit your changes to that branch.

4. Ensure the pipeline is passing on your commits.

5. Tag a project maintainer for review, (rmassing)

Authors
-------

Rob Massingill (rmassing@cisco.com)


